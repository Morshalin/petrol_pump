$(document).ready(function() {
    $('.month').MonthPicker({ Button: false });
});
